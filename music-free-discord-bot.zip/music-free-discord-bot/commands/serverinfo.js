const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports = {
 data: new SlashCommandBuilder().setName("serverinfo").setDescription("Server ki information dikhata hai."),
 async execute(i) {
  const g=i.guild;
  const e=new EmbedBuilder().setTitle(`🏠 ${g.name}`).addFields(
   {name:"Owner",value:`<@${g.ownerId}>`,inline:true},
   {name:"Members",value:String(g.memberCount),inline:true},
   {name:"Channels",value:String(g.channels.cache.size),inline:true},
   {name:"Roles",value:String(g.roles.cache.size),inline:true},
   {name:"Created",value:`<t:${Math.floor(g.createdTimestamp/1000)}:D>`,inline:true}
  );
  if(g.iconURL()) e.setThumbnail(g.iconURL({size:256}));
  await i.reply({embeds:[e]});
 }
};