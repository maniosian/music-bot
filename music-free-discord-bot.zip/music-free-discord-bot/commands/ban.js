const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("ban").setDescription("Member ko ban karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
 .addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.BanMembers))return i.reply({content:"❌ Ban Members permission required.",ephemeral:true});
 const u=i.options.getUser("user");const m=await i.guild.members.fetch(u.id).catch(()=>null);if(m&&!m.bannable)return i.reply({content:"❌ Main is member ko ban nahi kar sakta.",ephemeral:true});
 await i.guild.members.ban(u,{reason:i.options.getString("reason")||"No reason"});await i.reply(`🔨 **${u.tag}** banned.`);}
};