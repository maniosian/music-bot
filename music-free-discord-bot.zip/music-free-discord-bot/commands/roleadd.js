const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("roleadd").setDescription("Member ko role deta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
 .addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addRoleOption(o=>o.setName("role").setDescription("Role").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageRoles))return i.reply({content:"❌ Manage Roles permission required.",ephemeral:true});
 const m=await i.guild.members.fetch(i.options.getUser("user").id),r=i.options.getRole("role");if(r.managed||r.position>=i.member.roles.highest.position)return i.reply({content:"❌ Is role ko manage nahi kar sakta.",ephemeral:true});
 await m.roles.add(r);await i.reply(`🎭 ${r} role **${m.user.tag}** ko de diya.`);}
};