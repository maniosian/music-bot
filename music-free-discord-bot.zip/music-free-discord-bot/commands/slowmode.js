const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("slowmode").setDescription("Channel slowmode set karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
 .addIntegerOption(o=>o.setName("seconds").setDescription("0-21600").setMinValue(0).setMaxValue(21600).setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageChannels))return i.reply({content:"❌ Manage Channels permission required.",ephemeral:true});
 const s=i.options.getInteger("seconds");await i.channel.setRateLimitPerUser(s);await i.reply(`🐢 Slowmode: **${s}s**`);}
};