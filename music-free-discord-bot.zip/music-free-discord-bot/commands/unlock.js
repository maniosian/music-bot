const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("unlock").setDescription("Current channel unlock karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageChannels))return i.reply({content:"❌ Manage Channels permission required.",ephemeral:true});
 await i.channel.permissionOverwrites.edit(i.guild.roles.everyone,{SendMessages:null});await i.reply("🔓 Channel unlocked.");}
};