const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("deleterole").setDescription("Role delete karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
 .addRoleOption(o=>o.setName("role").setDescription("Role").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageRoles))return i.reply({content:"❌ Manage Roles permission required.",ephemeral:true});
 const r=i.options.getRole("role");if(r.managed||r.position>=i.member.roles.highest.position)return i.reply({content:"❌ Is role ko delete nahi kar sakta.",ephemeral:true});
 await r.delete();await i.reply(`🗑️ Role **${r.name}** deleted.`);}
};