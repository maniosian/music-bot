const { SlashCommandBuilder } = require("discord.js");
module.exports = {
 data: new SlashCommandBuilder().setName("ping").setDescription("Bot latency check karta hai."),
 async execute(i) { await i.reply(`🏓 Pong! API: **${i.client.ws.ping}ms**`); }
};