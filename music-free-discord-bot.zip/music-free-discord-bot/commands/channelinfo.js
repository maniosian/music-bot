const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("channelinfo").setDescription("Channel ki information.")
 .addChannelOption(o=>o.setName("channel").setDescription("Channel").setRequired(false)),
 async execute(i){const c=i.options.getChannel("channel")||i.channel;const e=new EmbedBuilder().setTitle(`📺 #${c.name}`).addFields(
 {name:"ID",value:c.id,inline:true},{name:"Type",value:String(c.type),inline:true});await i.reply({embeds:[e]});}
};