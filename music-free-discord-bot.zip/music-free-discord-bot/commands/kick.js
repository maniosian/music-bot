const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("kick").setDescription("Member ko server se kick karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
 .addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.KickMembers))return i.reply({content:"❌ Kick Members permission required.",ephemeral:true});
 const u=i.options.getUser("user"),m=await i.guild.members.fetch(u.id).catch(()=>null);if(!m)return i.reply({content:"❌ Member nahi mila.",ephemeral:true});
 if(!m.kickable)return i.reply({content:"❌ Main is member ko kick nahi kar sakta.",ephemeral:true});
 await m.kick(i.options.getString("reason")||"No reason");await i.reply(`👢 **${u.tag}** kicked.`);}
};