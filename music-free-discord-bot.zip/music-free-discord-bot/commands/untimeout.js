const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("untimeout").setDescription("Member ka timeout remove karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
 .addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers))return i.reply({content:"❌ Moderate Members permission required.",ephemeral:true});
 const u=i.options.getUser("user"),m=await i.guild.members.fetch(u.id);if(!m.moderatable)return i.reply({content:"❌ Main is member ko modify nahi kar sakta.",ephemeral:true});
 await m.timeout(null);await i.reply(`✅ **${u.tag}** ka timeout remove ho gaya.`);}
};