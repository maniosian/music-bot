const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("reverse").setDescription("Text reverse karta hai.")
 .addStringOption(o=>o.setName("text").setDescription("Text").setRequired(true)),
 async execute(i){await i.reply(i.options.getString("text").split("").reverse().join(""));}};