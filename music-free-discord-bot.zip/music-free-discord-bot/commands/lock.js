const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("lock").setDescription("Current channel ko members ke liye lock karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageChannels))return i.reply({content:"❌ Manage Channels permission required.",ephemeral:true});
 await i.channel.permissionOverwrites.edit(i.guild.roles.everyone,{SendMessages:false});await i.reply("🔒 Channel locked.");}
};