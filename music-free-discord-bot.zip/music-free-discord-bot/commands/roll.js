const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("roll").setDescription("Dice roll karta hai.")
 .addIntegerOption(o=>o.setName("sides").setDescription("2-100").setMinValue(2).setMaxValue(100).setRequired(false)),
 async execute(i){const n=i.options.getInteger("sides")||6;await i.reply(`🎲 **${Math.floor(Math.random()*n)+1}** / ${n}`);}
};