const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const warnings = new Map();
module.exports={
 data:new SlashCommandBuilder().setName("warn").setDescription("Member ko warning deta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
 .addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers))return i.reply({content:"❌ Moderate Members permission required.",ephemeral:true});
 const u=i.options.getUser("user"),r=i.options.getString("reason"),arr=warnings.get(u.id)||[];arr.push({reason:r,by:i.user.id,at:Date.now()});warnings.set(u.id,arr);await i.reply(`⚠️ **${u.tag}** warned. Total warnings: **${arr.length}**`);}
};