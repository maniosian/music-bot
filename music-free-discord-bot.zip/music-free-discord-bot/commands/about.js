const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("about").setDescription("Bot ke baare mein.")
 ,async execute(i){await i.reply("🤖 **Music-Free Discord Bot**\n38 slash commands\n⚡ Node.js + discord.js\n🎵 Lavalink/music system intentionally removed.");}};