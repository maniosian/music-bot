const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("nick").setDescription("Member ka nickname change karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
 .addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true))
 .addStringOption(o=>o.setName("nickname").setDescription("New nickname").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageNicknames))return i.reply({content:"❌ Manage Nicknames permission required.",ephemeral:true});
 const u=i.options.getUser("user"),m=await i.guild.members.fetch(u.id);if(!m.manageable)return i.reply({content:"❌ Main nickname change nahi kar sakta.",ephemeral:true});
 await m.setNickname(i.options.getString("nickname"));await i.reply(`✏️ **${u.tag}** ka nickname update ho gaya.`);}
};