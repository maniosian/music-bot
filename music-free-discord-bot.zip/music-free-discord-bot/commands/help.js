const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports = {
  data: new SlashCommandBuilder().setName("help").setDescription("Bot ki commands ki list dikhata hai."),
  async execute(i) {
    const groups = {
      "Info": "ping, serverinfo, userinfo, avatar, membercount, roleinfo, channelinfo, botinfo, uptime",
      "Moderation": "clear, purge, kick, ban, unban, timeout, untimeout, warn, warnings, lock, unlock, slowmode, nick",
      "Roles": "roleadd, roleremove, createrole, deleterole",
      "Utility": "say, announce, embed, poll, choose, coinflip, roll, 8ball, reverse",
      "Other": "about, invite, servericon, serverbanner, echo"
    };
    const e = new EmbedBuilder().setTitle("📚 Bot Commands").setDescription(
      Object.entries(groups).map(([k,v]) => `**${k}:** \`${v.replaceAll(", ", "`, `")}\``).join("\n\n")
    );
    await i.reply({ embeds: [e] });
  }
};