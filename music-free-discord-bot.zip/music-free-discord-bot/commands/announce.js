const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("announce").setDescription("Announcement embed send karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
 .addStringOption(o=>o.setName("title").setDescription("Title").setRequired(true)).addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageMessages))return i.reply({content:"❌ Manage Messages permission required.",ephemeral:true});
 const e=new EmbedBuilder().setTitle(`📢 ${i.options.getString("title")}`).setDescription(i.options.getString("message")).setFooter({text:`By ${i.user.tag}`}).setTimestamp();await i.channel.send({embeds:[e]});await i.reply({content:"✅ Announcement sent.",ephemeral:true});}
};