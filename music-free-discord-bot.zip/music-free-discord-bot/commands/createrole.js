const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("createrole").setDescription("New role banata hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
 .addStringOption(o=>o.setName("name").setDescription("Role name").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageRoles))return i.reply({content:"❌ Manage Roles permission required.",ephemeral:true});
 const r=await i.guild.roles.create({name:i.options.getString("name"),reason:`Created by ${i.user.tag}`});await i.reply(`✅ Role created: ${r}`);}
};