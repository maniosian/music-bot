const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports = {
 data: new SlashCommandBuilder().setName("userinfo").setDescription("User ki information dikhata hai.")
  .addUserOption(o=>o.setName("user").setDescription("User").setRequired(false)),
 async execute(i) {
  const u=i.options.getUser("user")||i.user, m=i.guild.members.cache.get(u.id);
  const e=new EmbedBuilder().setTitle(`👤 ${u.tag}`).addFields(
   {name:"User ID",value:u.id,inline:true},
   {name:"Account",value:`<t:${Math.floor(u.createdTimestamp/1000)}:R>`,inline:true},
   {name:"Joined",value:m?`<t:${Math.floor(m.joinedTimestamp/1000)}:R>`:"Unknown",inline:true}
  ).setThumbnail(u.displayAvatarURL({size:256}));
  await i.reply({embeds:[e]});
 }
};