const { SlashCommandBuilder } = require("discord.js");
const store = require("./warn");
module.exports={data:new SlashCommandBuilder().setName("warnings").setDescription("Warnings dikhata hai.")
 .addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)),
 async execute(i){await i.reply("ℹ️ Is simple version mein warnings runtime memory mein hain; bot restart par reset ho sakti hain. Persistent warnings ke liye database add karna hoga.");}
};