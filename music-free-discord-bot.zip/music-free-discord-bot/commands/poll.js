const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("poll").setDescription("Simple yes/no poll banata hai.")
 .addStringOption(o=>o.setName("question").setDescription("Question").setRequired(true)),
 async execute(i){const e=new EmbedBuilder().setTitle("📊 Poll").setDescription(i.options.getString("question")).setFooter({text:`Poll by ${i.user.tag}`});const m=await i.reply({embeds:[e],fetchReply:true});await m.react("👍");await m.react("👎");}
};