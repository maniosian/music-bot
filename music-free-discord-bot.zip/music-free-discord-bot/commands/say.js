const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("say").setDescription("Bot se message send karwata hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
 .addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageMessages))return i.reply({content:"❌ Manage Messages permission required.",ephemeral:true});
 await i.channel.send(i.options.getString("message"));await i.reply({content:"✅ Sent.",ephemeral:true});}
};