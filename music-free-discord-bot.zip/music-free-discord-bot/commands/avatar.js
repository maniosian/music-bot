const { SlashCommandBuilder } = require("discord.js");
module.exports = {
 data:new SlashCommandBuilder().setName("avatar").setDescription("User ka avatar dikhata hai.")
  .addUserOption(o=>o.setName("user").setDescription("User").setRequired(false)),
 async execute(i){const u=i.options.getUser("user")||i.user; await i.reply({content:u.displayAvatarURL({size:1024,extension:"png"})});}
};