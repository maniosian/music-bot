const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("choose").setDescription("Multiple options mein se random choose karta hai.")
 .addStringOption(o=>o.setName("options").setDescription("Comma separated options").setRequired(true)),
 async execute(i){const a=i.options.getString("options").split(",").map(x=>x.trim()).filter(Boolean);if(a.length<2)return i.reply("❌ Kam se kam 2 options do.");await i.reply(`🎯 **${a[Math.floor(Math.random()*a.length)]}**`);}
};