const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("roleinfo").setDescription("Role ki information.")
 .addRoleOption(o=>o.setName("role").setDescription("Role").setRequired(true)),
 async execute(i){const r=i.options.getRole("role");const e=new EmbedBuilder().setTitle(`🎭 ${r.name}`).addFields(
 {name:"ID",value:r.id,inline:true},{name:"Members",value:String(r.members.size),inline:true},{name:"Position",value:String(r.position),inline:true});await i.reply({embeds:[e]});}
};