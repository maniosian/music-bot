const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("coinflip").setDescription("Coin flip."),
 async execute(i){await i.reply(Math.random()<0.5?"🪙 **Heads!**":"🪙 **Tails!**");}
};