const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("8ball").setDescription("Magic 8-ball answer.")
 .addStringOption(o=>o.setName("question").setDescription("Question").setRequired(true)),
 async execute(i){const a=["Haan, bilkul.","Nahi.","Maybe.","Chances high hain.","Abhi kehna mushkil hai.","Definitely!","Dobara try karo.","Mujhe lagta hai haan."];await i.reply(`🎱 ${a[Math.floor(Math.random()*a.length)]}`);}
};