const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("unban").setDescription("User ka ban remove karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
 .addStringOption(o=>o.setName("user_id").setDescription("Discord User ID").setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.BanMembers))return i.reply({content:"❌ Ban Members permission required.",ephemeral:true});
 const id=i.options.getString("user_id");await i.guild.members.unban(id).catch(()=>null);await i.reply(`🔓 Ban remove karne ki request complete: **${id}**`);}
};