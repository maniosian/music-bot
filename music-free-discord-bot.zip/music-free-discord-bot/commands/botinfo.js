const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("botinfo").setDescription("Bot information."),
 async execute(i){const e=new EmbedBuilder().setTitle("🤖 Bot Info").addFields(
 {name:"Name",value:i.client.user.tag,inline:true},{name:"Servers",value:String(i.client.guilds.cache.size),inline:true},
 {name:"Commands",value:String(i.client.commands.size),inline:true},{name:"Node.js",value:process.version,inline:true});await i.reply({embeds:[e]});}};