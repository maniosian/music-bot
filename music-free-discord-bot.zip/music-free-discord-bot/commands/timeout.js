const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("timeout").setDescription("Member ko timeout deta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
 .addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true))
 .addIntegerOption(o=>o.setName("minutes").setDescription("1-40320 minutes").setMinValue(1).setMaxValue(40320).setRequired(true))
 .addStringOption(o=>o.setName("reason").setDescription("Reason")),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers))return i.reply({content:"❌ Moderate Members permission required.",ephemeral:true});
 const u=i.options.getUser("user"),m=await i.guild.members.fetch(u.id).catch(()=>null);if(!m?.moderatable)return i.reply({content:"❌ Main is member ko timeout nahi de sakta.",ephemeral:true});
 await m.timeout(i.options.getInteger("minutes")*60000,i.options.getString("reason")||"No reason");await i.reply(`⏳ **${u.tag}** ko timeout diya gaya.`);}
};