const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
module.exports={
 data:new SlashCommandBuilder().setName("purge").setDescription("Messages bulk delete karta hai.")
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
 .addIntegerOption(o=>o.setName("amount").setDescription("1-100").setMinValue(1).setMaxValue(100).setRequired(true)),
 async execute(i){if(!i.memberPermissions.has(PermissionFlagsBits.ManageMessages))return i.reply({content:"❌ Manage Messages permission required.",ephemeral:true});
 const n=i.options.getInteger("amount");const msgs=await i.channel.bulkDelete(n,true);await i.reply({content:`🗑️ **${msgs.size}** messages purged.`,ephemeral:true});}
};