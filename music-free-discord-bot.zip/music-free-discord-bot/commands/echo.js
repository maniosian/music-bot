const { SlashCommandBuilder } = require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("echo").setDescription("Private echo test.")
 .addStringOption(o=>o.setName("text").setDescription("Text").setRequired(true)),
 async execute(i){await i.reply({content:`🔊 ${i.options.getString("text")}`,ephemeral:true});}};