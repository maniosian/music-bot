# Music-Free Discord Bot

Ye bot Lavalink/Kazagumo ke bina banaya gaya hai. Isliye music connection/502 problem is project mein nahi hogi.

## Commands
38 slash commands included:
help, ping, serverinfo, userinfo, avatar, membercount, roleinfo, channelinfo, botinfo, uptime,
clear, purge, kick, ban, unban, timeout, untimeout, warn, warnings, lock, unlock, slowmode, nick,
roleadd, roleremove, createrole, deleterole, say, announce, embed, poll, choose, coinflip, roll,
8ball, reverse, echo, about.

## Environment variables
TOKEN = Discord bot token
CLIENT_ID = Discord Application ID
GUILD_ID = test server ID (recommended; commands appear quickly)
PORT = Render port, normally 10000

## Local setup
1. Rename `.env.example` to `.env`
2. Fill TOKEN, CLIENT_ID, GUILD_ID.
3. `npm install`
4. `npm run deploy`
5. `npm start`

## Render
Build Command: `npm install`
Start Command: `npm start`
Add the same environment variables in Render.
No Lavalink variables are needed.

## Important
- Bot needs appropriate Discord permissions for moderation commands.
- Bot role must be above roles/members it needs to manage.
- `/warn` is intentionally a simple in-memory warning system; warnings reset if the bot restarts.
- Do not upload `.env` to GitHub.
