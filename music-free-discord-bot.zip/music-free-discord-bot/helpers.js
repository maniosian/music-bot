const { PermissionFlagsBits } = require("discord.js");

function hasPerm(interaction, permission) {
  return interaction.memberPermissions?.has(permission);
}

async function requirePerm(interaction, permission, label = "is command ke liye") {
  if (hasPerm(interaction, permission)) return true;
  await interaction.reply({ content: `❌ Aapke paas ${label} permission nahi hai.`, ephemeral: true });
  return false;
}

function targetMember(interaction, user) {
  return interaction.guild.members.cache.get(user.id) || null;
}

module.exports = { hasPerm, requirePerm, targetMember, PermissionFlagsBits };
